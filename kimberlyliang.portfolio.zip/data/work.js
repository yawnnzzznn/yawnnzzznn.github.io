(function (global) {
  'use strict';

  global.WORK = [
    {
      company: 'Meet Fresh',
      role: 'Social Media Marketing Manager',
      period: 'Oct 2026 – Present',
      location: '',
      bullets: [
        'Lead a team of 6 marketing staff by assigning projects, setting deadlines, and reviewing content to keep the content calendar on schedule and on brand.',
        'Develop and execute the social media strategy across Instagram, TikTok, and Google/Yelp to promote the store, grow the local following, and build brand awareness to 300K+ viewers.',
        'Direct 50+ short-form videos and photo shoots for seasonal launches and promotions, keeping all content aligned with brand guidelines.',
        'Track 5+ KPIs (reach, engagement, views, follower growth) in Instagram Insights and TikTok Analytics to refine content and guide campaign decisions.'
      ]
    },
    {
      company: 'CJL Trading',
      role: 'Operations Manager',
      period: 'Aug 2024 – Aug 2026',
      location: '',
      bullets: [
        'Maintained data records and cross-checked invoices, checks, and payment documentation, catching 10+ discrepancies a week before processing in a fast-paced wholesale environment.',
        'Communicated daily with 30+ customers, vendors, and coworkers to verify payment information and place purchase orders, keeping inventory stocked and orders on schedule.',
        'Processed payroll for 50+ staff members while running monthly inventory inspections and meeting every deadline.',
        'Researched and recommended 5 digital inventory-tracking systems to address recurring inventory inaccuracies, giving management a clear path to fewer errors and better purchasing decisions.'
      ]
    },
    {
      company: 'Go Go Sales',
      role: 'Administrative Coordinator',
      period: 'Jul 2022 – Jun 2024',
      location: '',
      bullets: [
        'Coordinated and scheduled deliveries for 30+ restaurant clients and led the delivery team, adapting routes as priorities shifted and keeping clients informed so deliveries stayed on time and on budget.',
        'Maintained organized records for 500+ customers and 100+ vendor accounts so the team could process orders and follow up quickly.',
        'Tracked and recorded 1,000+ financial transactions in a POS system, keeping sales records accurate and reliable.'
      ]
    }
  ];

  global.EDUCATION = [
    {
      school: 'University of California, Riverside',
      division: 'School of Business',
      degree: 'B.A. Business Administration — Concentration in Marketing. Coursework: Service Marketing, Marketing in Global Environments, Marketing Research, Consumer Behavior, Advertising & Communications, Competitive Analysis.',
      period: 'Graduated June 2026'
    },
    {
      school: 'Fudan University',
      division: 'UC Education Abroad Program · Shanghai',
      degree: 'Coursework: Technology Entrepreneurship, Global Strategy.',
      period: 'Aug 2025 – Jan 2026'
    }
  ];

  global.SKILLS = {
    marketing: ['Social Media Strategy', 'Content Creation', 'Influencer Marketing', 'Brand Partnerships', 'Market Research'],
    tools: ['Instagram Insights', 'TikTok Analytics', 'CapCut', 'Canva', 'Pinterest', 'Photoshop', 'Excel', 'AI (Claude, Copilot)'],
    languages: ['English', 'Mandarin', 'Cantonese'],
    interests: ['Photography', 'Beauty & Skincare Trends', 'Creator Economy', 'Food & Cafe Culture', 'Gaming Communities']
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
