(function (global) {
  'use strict';

  global.PROJECTS = [
    {
      id: 'creator',
      kind: 'product',
      featured: true,
      title: 'Beauty & Lifestyle Creator',
      tagline: '1.8M+ views in two months and $10,000+ in partnership revenue.',
      url: null,
      period: 'Sep 2022 – Present',
      role: 'TikTok creator · YesStyle partner',
      stack: ['TikTok', 'Influencer Marketing', 'Affiliate'],
      bullets: [
        'Plan and produce short-form beauty and lifestyle content from trend research and audience insights, reaching 1.8M+ views in the past two months.',
        'Run influencer and affiliate campaigns with brands including COSRX, OASAP, Mimi\u2019s, and JVL, generating $10,000+ in partnership revenue.',
        'Drove $1,000+ in affiliate sales by testing hooks, captions, and posting cadence.'
      ],
      caseStudy: null
    },
    {
      id: 'meet-fresh-social',
      kind: 'product',
      featured: true,
      title: 'Meet Fresh Social Program',
      tagline: 'Local brand awareness grown to 300K+ viewers.',
      url: null,
      period: 'Oct 2026 – Present',
      role: 'Social media marketing manager',
      stack: ['Instagram', 'TikTok', 'Google / Yelp'],
      bullets: [
        'Built and run the store\u2019s social strategy across Instagram, TikTok, and Google/Yelp.',
        'Direct 50+ short-form videos and photo shoots for seasonal launches and promotions with a team of 6.',
        'Track 5+ KPIs in Instagram Insights and TikTok Analytics to decide what to make next.'
      ],
      caseStudy: null
    },
    {
      id: 'smartwatch-research',
      kind: 'project',
      featured: false,
      title: 'Smartwatch Market Research',
      tagline: null,
      url: null,
      period: 'UCR',
      role: 'Research lead',
      stack: ['Surveys', 'Focus Groups', 'ANOVA & Regression'],
      bullets: [
        'Developed a stress- and emotion-tracking smartwatch concept and tested demand for it.',
        'Surveyed 100+ participants and ran 3 focus groups.',
        'Analyzed results with ANOVA and regression to shape the product recommendation.'
      ],
      caseStudy: null
    },
    {
      id: 'cosrx-launch',
      kind: 'project',
      featured: false,
      title: 'COSRX Beauty Box Launch',
      tagline: null,
      url: null,
      period: '2024',
      role: 'Go-to-market & partnerships',
      stack: ['YesStyle', 'Influencer Launch', 'Giveaways'],
      bullets: [
        'Launched sponsored products with a simple narrative: problem \u2192 routine \u2192 result, tailored to TikTok-native viewing.',
        'Ran beauty box giveaway mechanics to drive saves, tags, and follows while seeding authentic reviews.',
        'Translated brand briefs into creator-native messaging without losing product accuracy or claims compliance.'
      ],
      caseStudy: null
    },
    {
      id: 'ugc-ad-series',
      kind: 'project',
      featured: false,
      title: 'Skincare UGC Ad Series',
      tagline: null,
      url: null,
      period: '2024',
      role: 'Messaging & creative testing',
      stack: ['Short-form Video', 'Hook Testing', 'CTAs'],
      bullets: [
        'Built a repeatable ad system: unboxing, routine integration, and proof-based before/after formats.',
        'Earned $1,000+ in commissions by iterating on hooks, captions, and posting cadence.',
        'Documented learnings into a creative playbook: what opens, what retains, what converts.'
      ],
      caseStudy: null
    },
    {
      id: 'positioning-audit',
      kind: 'project',
      featured: false,
      title: 'Beauty Brand Messaging Audit',
      tagline: null,
      url: null,
      period: '2025',
      role: 'Positioning & competitive analysis',
      stack: ['Positioning', 'Competitive Teardown', 'Insights'],
      bullets: [
        'Audited 5+ K-beauty product pages and TikTok creatives to map claims, proof points, and gaps.',
        'Rewrote positioning into benefit-led messaging: who it is for, what changes, and why to believe it.',
        'Proposed a launch checklist: hero message, 3 proof pillars, objection handlers, and creator brief.'
      ],
      caseStudy: null
    },
    {
      id: 'restaurant-discovery',
      kind: 'project',
      featured: false,
      title: 'Local Discovery Content Series',
      tagline: null,
      url: null,
      period: '2023 – Present',
      role: 'Audience growth & storytelling',
      stack: ['Content Strategy', 'Local SEO', 'Community'],
      bullets: [
        'Turned a personal love of discovering new restaurants into a discovery series built on strong hooks and honest reviews.',
        'Practiced core PMM skills in public: audience empathy, narrative arcs, and consistent publishing.',
        'Grew instincts for what makes people save, share, and try something new.'
      ],
      caseStudy: null
    },
    {
      id: 'gtm-playbook',
      kind: 'project',
      featured: false,
      title: 'Creator-Led GTM Playbook',
      tagline: null,
      url: null,
      period: '2025',
      role: 'Go-to-market strategy',
      stack: ['GTM', 'Launch Plan', 'Enablement'],
      bullets: [
        'Drafted a lightweight GTM template for creator-led launches: audience, message, channels, timeline, and success metrics.',
        'Defined pre-launch, launch, and post-launch creator deliverables with clear CTAs and tracking.',
        'Designed to be reusable for DTC beauty and lifestyle brands entering TikTok Shop.'
      ],
      caseStudy: null
    }
  ];

  global.COURSEWORK = [
    { index: 'UCR', title: 'Service Marketing', url: null },
    { index: 'UCR', title: 'Marketing in Global Environments', url: null },
    { index: 'UCR', title: 'Marketing Research', url: null },
    { index: 'UCR', title: 'Consumer Behavior', url: null },
    { index: 'UCR', title: 'Advertising & Communications', url: null },
    { index: 'UCR', title: 'Competitive Analysis', url: null },
    { index: 'FUDAN', title: 'Technology Entrepreneurship', url: null },
    { index: 'FUDAN', title: 'Global Strategy', url: null }
  ];
})(typeof globalThis !== 'undefined' ? globalThis : this);
